# Eve

Tiny event helping JavaScript library.

For use case look at e.html
